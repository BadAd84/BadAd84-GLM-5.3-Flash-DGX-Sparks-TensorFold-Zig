# RECORD.md - patches/solo-cuts
## Current base (re-seated 2026-11-20, lane reseat-tip)
What it is: our solo-step cuts: a solo step does not span a request start, and may end at one.

Source of the text: this repo's `patches/solo-cuts` as it stood on the pin `1ece6e6dbbc073582d50738ce8e73e3c3261a73b` (itself re-seated there by
lane(s) on 2026-11-20), each patch's own delta played onto upstream main `46c6ee229d2ea28bde8b273381c0f0443861cdd6` with a chain of
three-way merges (`git merge-tree --merge-base=<old tree> <new tree> <old tree after the patch>`), so a
patch that applied clean is regenerated with its original header and hunks intact (only line offsets and
context lines may move) and a patch that did not was settled by hand against the upstream commit that moved
the code. Nothing was compiled on the workstation; the gate ran on the shared gate host.

This package applies to upstream TensorFold main `46c6ee229d2ea28bde8b273381c0f0443861cdd6` with the packages before it in the order
engine, pr1411, cache-salt, learn-starts, solo-cuts, disk-any-position, restore-held: it takes the tree `c5baac89069b693c47f53da15ffd728d56b76cda` to `2bc09111e6e0f47196cd9761a309348a778f64cc` (2 patches, 45 in all; both ids are `git write-tree` on the tree
built with `scripts/apply.sh` and the packages' `apply.sh` in that order). The tree of upstream main itself is
`56ccf3b8bf3a621c094e6cfb1981af904dd517e7`.

No repair was needed: both patches applied clean as a three-way merge of their own delta.

Gate: Full run `sg-20261121-000728` on the gate host (<gate-host>, x86_64; `--jobs 4 --max-load 90 --mem-max 8`), the pristine main (tree `56ccf3b8bf3a`) against this series (47 patches in the seven packages, tree `1fd680b2b681`, the id the run expected and the one this package set rebuilds): `check-native-cuda-host` (8 of 8 steps), `compile-cuda-tests` (10 of 10 steps), `test-glm-ring-host`, `test-glm-logprobs-host`, `test-rows-host`, `test-glm-pdl-scan` (3 of 3 tests), `test-kernel-contract` (269 of 269 tests) and `fmt` rc 0 on both trees; `test-cuda-host` rc 0 on both, 8,027 of 8,070 tests passed on the stack (43 skipped) and 7,811 of 7,854 on the base, no failing name on either and none new; `test-glm-onepass-order-host` rc 0 on the stack and not a step of the base; lean base 7,202 files and 168 problems, head 7,272 and 168, 0 new. Verdict PASS.

Patches in this package, in file-name order:
- `0001-glm-solo-between-starts.patch`
- `0002-glm-solo-to-start.patch`
