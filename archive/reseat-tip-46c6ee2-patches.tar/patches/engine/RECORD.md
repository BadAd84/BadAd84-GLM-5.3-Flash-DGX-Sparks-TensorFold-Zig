# RECORD.md - patches/engine
## Current base (re-seated 2026-11-20, lane reseat-tip)
What it is: the recipe's engine patch series: our levers on upstream TensorFold, numbered, applied in file-name order.

Source of the text: this repo's `patches/engine` as it stood on the pin `1ece6e6dbbc073582d50738ce8e73e3c3261a73b` (itself re-seated there by
lane(s) on 2026-11-20), each patch's own delta played onto upstream main `46c6ee229d2ea28bde8b273381c0f0443861cdd6` with a chain of
three-way merges (`git merge-tree --merge-base=<old tree> <new tree> <old tree after the patch>`), so a
patch that applied clean is regenerated with its original header and hunks intact (only line offsets and
context lines may move) and a patch that did not was settled by hand against the upstream commit that moved
the code. Nothing was compiled on the workstation; the gate ran on the shared gate host.

This package applies to upstream TensorFold main `46c6ee229d2ea28bde8b273381c0f0443861cdd6` with the packages before it in the order
engine, pr1411, cache-salt, learn-starts, solo-cuts, disk-any-position, restore-held: it takes the tree `56ccf3b8bf3a621c094e6cfb1981af904dd517e7` to `0d58ce7445c248f05d24ecc3d30df391960715d7` (38 patches, 38 in all; both ids are `git write-tree` on the tree
built with `scripts/apply.sh` and the packages' `apply.sh` in that order). The tree of upstream main itself is
`56ccf3b8bf3a621c094e6cfb1981af904dd517e7`.

This re-seat's repairs, all three in this package:
- `0005-kda-pad-one-width.patch`: one conflict, in `zig/src/families/glm/cuda_kda_block.zig`, where upstream's
  `ae8f0a10f` (#3697) added `tile_pad` beside the `pad_to` declarations this patch also edits. Both sides kept
  (upstream's `tile_pad` first, this patch's `dump_driver`/`dump_path` after it). Its second rejected hunk,
  `zig/src/families/glm/cuda_tile.zig`, is context only (upstream reworded the doc line above `padKdaInputs`) and
  the three-way merge placed the block unchanged. #3697 makes the pad layout this patch was written for upstream's
  default and keeps `TF_GLM_KDA_PAD=1` as the common width plus `glm_mm` tiles, so the patch still adds exactly its
  own: the `TF_GLM_KDA_DUMP` row and the one dump of the first fused input stack. Nothing else moved.
- `0019-sparse-onepass.patch`: one conflict, its `glm_onepass` fatbin row in `zig/src/cuda/kernels.zig`, at the line
  upstream now holds its `inkling2_attn`/`inkling2_pattn` rows. Kept upstream's two rows and put `glm_onepass` after
  them, before `glm_quant`.
- `0020-onepass-pipe.patch`: one rejected hunk in the same file, its `glm_onepass_pipe` row; in the chain the row
  follows `glm_onepass`, which 0019 now places after upstream's rows, so the three-way merge settled it there with
  none of the patch's lines changed.

Every patch's added and removed lines are identical, as a multiset, to the file it was re-seated from: only line
offsets, context lines and the three placements above moved. The three repaired patches carry a re-seat note in
their header; the other 44 headers are byte-identical to the source files.

Gate: Full run `sg-20261121-000728` on the gate host (<gate-host>, x86_64; `--jobs 4 --max-load 90 --mem-max 8`), the pristine main (tree `56ccf3b8bf3a`) against this series (47 patches in the seven packages, tree `1fd680b2b681`, the id the run expected and the one this package set rebuilds): `check-native-cuda-host` (8 of 8 steps), `compile-cuda-tests` (10 of 10 steps), `test-glm-ring-host`, `test-glm-logprobs-host`, `test-rows-host`, `test-glm-pdl-scan` (3 of 3 tests), `test-kernel-contract` (269 of 269 tests) and `fmt` rc 0 on both trees; `test-cuda-host` rc 0 on both, 8,027 of 8,070 tests passed on the stack (43 skipped) and 7,811 of 7,854 on the base, no failing name on either and none new; `test-glm-onepass-order-host` rc 0 on the stack and not a step of the base; lean base 7,202 files and 168 problems, head 7,272 and 168, 0 new. Verdict PASS.

Patches in this package, in file-name order:
- `0001-shared-window-width.patch`
- `0002-rows-worker-and-quiesce-drain.patch`
- `0003-prompt-bench.patch`
- `0004-ovn-knob-registry.patch`
- `0005-kda-pad-one-width.patch`
- `0006-draft-knobs.patch`
- `0007-index-decode-windows.patch`
- `0008-kept-walk-prefix-helper.patch`
- `0009-ring-past-refusal.patch`
- `0010-ovn-check-table.patch`
- `0012-index-sched-decode-pools32.patch`
- `0013-index-regroup.patch`
- `0014-lanes-step-split.patch`
- `0015-plain-margin.patch`
- `0016-exchange-kb.patch`
- `0017-router-warm.patch`
- `0018-win-free.patch`
- `0019-sparse-onepass.patch`
- `0020-onepass-pipe.patch`
- `0021-kda-chunked.patch`
- `0022-mm-knobs.patch`
- `0023-mla-knobs.patch`
- `0024-glue-fuse.patch`
- `0025-head-block-rule.patch`
- `0026-head-flag.patch`
- `0027-exl3-dec-order.patch`
- `0028-memo-equal-strindex.patch`
- `0029-fp8-tile-ahead.patch`
- `0030-render-once-host-once.patch`
- `0031-glm-exl3-x3-decode.patch`
- `0032-glm-keep-seqs.patch`
- `0033-glm-off-effort-line.patch`
- `0034-glm-no-copy.patch`
- `0035-glm-mm-ovn-check.patch`
- `0036-glm-latent-rows.patch`
- `0037-glm-side-prio.patch`
- `0038-glm-piece-front.patch`
- `0039-glm-piece-kda.patch`
